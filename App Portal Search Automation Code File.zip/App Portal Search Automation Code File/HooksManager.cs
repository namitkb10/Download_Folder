﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using WebDriverManager.DriverConfigs.Impl;
using WindowsInput;
using WindowsInput.Native;
using AppPortalFlexera.CommonClass;
using OpenQA.Selenium.Firefox;
using System.Data.SqlClient;

namespace AppPortalFlexera.Framework
{
    [Binding]
    public class HooksManager
    {
        // public static string servicesAppPortal = "Data Source=10.75.205.8;Initial Catalog=Gls_app;Integrated Security=True;";
        public static string servicesAppPortal = "Data Source=10.75.205.8;Initial Catalog=Build65_Upgradetest;Integrated Security=True;";
        public static SqlConnection connectAppPortal;
        public static IWebDriver driver = null;
        public static InputSimulator inputSim = new InputSimulator();
        public static ClassCommon cc = new ClassCommon();
        static WaitManager waitManager = new WaitManager();

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            Console.WriteLine("Started Before Test Run...");

            connectAppPortal = connectAppPortal.DBConnect(servicesAppPortal);

            driverSetUp();

            login();

        }

        //[BeforeScenario]
        //public void BeforeScenario()
        //{
        //    driverSetUp();

        //    login();

        //}

        public static void driverSetUp()
        {

            if (cc.getDataFromFile("browser") == "chrome")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                driver = new ChromeDriver();
            }
            else if (cc.getDataFromFile("browser") == "edge")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());
                driver = new EdgeDriver();
            }
            else if (cc.getDataFromFile("browser") == "firefox")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                driver = new FirefoxDriver();
            }
            else
            {
                Console.WriteLine("Not a valid browser name");
            }

            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
        }
        public static void login()
        {
            Thread.Sleep(3000);
            string launchingURL = cc.getDataFromFile("url");
            // driver.Navigate().GoToUrl("http://10.75.205.122/esd/");
            driver.Navigate().GoToUrl(launchingURL);
            Thread.Sleep(3000);
            // Enter username
            string uname = cc.getDataFromFile("username");
            inputSim.Keyboard.TextEntry(uname);
            Thread.Sleep(1000);
            // press Tab key 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            // Enter Password
            string passwd = cc.getDataFromFile("pass");
            inputSim.Keyboard.TextEntry(passwd);
            Thread.Sleep(6000);
            inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(40000);
            Assert.True(driver.Title.Contains("Flexera Software App Portal"));
            Console.WriteLine("Authentication Pop-up Login Completed through hooks");
        }

        [AfterScenario]
        public static void AfterScenario()
        {
            var CaptureManager = new CaptureManager(driver);
            CaptureManager.CaptureScreenshotAndPageSourceUponFailure();

        }

        //[AfterScenario]
        //public void AfterScenario()
        //{
        //    Console.WriteLine("Running after scenario...");
        //    //var driver = _container.Resolve<IWebDriver>();

        //    Console.WriteLine("After Scenario driver value is: " + driver);

        //    /*if (driver != null)
        //    {
        //        driver.Quit();
        //    }*/
        //}

        [AfterTestRun]
        public static void AfterTestRun()
        {
            Console.WriteLine("Running after scenario...");

            connectAppPortal.Close();
            //close the connection

            Console.WriteLine("After Scenario driver value is: " + driver);

            if (driver != null)
            {
                driver.Quit();
            }
        }
    }
}