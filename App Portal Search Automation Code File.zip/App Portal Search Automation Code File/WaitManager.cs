﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;

namespace AppPortalFlexera.Framework
{
    public class WaitManager
    {
        public static string browser = "";
        public static Int32 webDriverExplictTimeoutInSeconds = 90;

        #region Wait
        public void ScrollToWebElement(By Locator)
        {
            try
            {
                ((IJavaScriptExecutor)HooksManager.driver).ExecuteScript("arguments[0].scrollIntoView({behavior: 'instant', block: 'center', inline: 'nearest'});", HooksManager.driver.FindElement(Locator));
            }
            catch (Exception) { }
        }

        public void UntilIsElementIsDisplayed(By Locator)
        {
            WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(Locator));
        }

        public void UntilIsElementIsNotDisplayed(By Locator)
        {
            WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(Locator));
        }

        public void UntilIsElementIsClickable(IWebElement element)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));

                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(element);
                        break;

                    default: break;
                }
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(element));

            }
            catch (Exception)
            {
                AssertionManager.Fail("Following element is not displayed : " + element + " at URL : " + HooksManager.driver.Url);
            }
        }
        public void UntilTextToBePresentInElement(IWebElement element, string text)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(element);
                        break;

                    default: break;
                }
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElement(element, text));

            }
            catch (Exception)
            {
                AssertionManager.Fail("Expect Text : " + text + "Actual Text: " + element.Text + " at URL : " + HooksManager.driver.Url);
            }
        }
        private bool IsElementPresent(IWebDriver driver, By locator)
        {
            //Set the timeout to something low
            try
            {
                /*driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(pauseTimeInSeconds * 10);
                Thread.Sleep(pauseTimeInSeconds * 3); */
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(2000 * 10);
                Thread.Sleep(2000 * 3);
                return driver.FindElements(locator).Count == 0 ? false : true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }

        }
        public void ForDocumentToBeReady()
        {
            try
            {
                //WebDriverWait wait = new WebDriverWait(HooksSpecFlow.driver, new TimeSpan(0, 0, readyStateTimeOutInSeconds));
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, 3000));

                wait.Until(driver1 => ((IJavaScriptExecutor)HooksManager.driver).ExecuteScript("return document.readyState").Equals("complete"));
                //wait.Until(d => (bool)(d as IJavaScriptExecutor).ExecuteScript("return jQuery.active == 0"));

            }
            catch (UnhandledAlertException)
            {
                //ExplicitWaitCall(taskDelayPauseTimeInSeconds);
                ExplicitWaitCall(5000);
                IAlert alert = HooksManager.driver.SwitchTo().Alert();
                alert.Accept();
            }
            catch (Exception)
            {

            }
        }
        private void StopPageLoad()
        {
            ((IJavaScriptExecutor)HooksManager.driver).ExecuteScript("return document.execCommand('Stop');");
        }
        public void ExplicitWaitCall(int HardPause)
        {
            Task.Delay(HardPause).Wait();
        }

        public void UntilValueToBePresentInElement(IWebElement element, string value)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));

                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(element);
                        break;

                    default: break;
                }
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementValue(element, value));

            }
            catch (Exception)
            {
                AssertionManager.Fail("Expect Value : " + value + "Actual Text: " + element.Text + " at URL : " + HooksManager.driver.Url);
            }
        }

        public IWebElement UntilElementIsDisplayedAndReturnIt(By Locator)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(Locator));


                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(Locator);
                        break;

                    default: break;
                }
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(Locator));
                return HooksManager.driver.FindElement(Locator);
            }
            catch (Exception)
            {
                return null;
            }
        }


        public void UntilIsElementIsSelected(IWebElement element)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeSelected(element, true));


                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(element);
                        break;

                    default: break;
                }
            }
            catch (Exception)
            {
                AssertionManager.Fail("Following element is not Selected : " + element + " at URL : " + HooksManager.driver.Url);
            }
        }
        public void UntilIsElementSelectionStateToBeTrue(IWebElement element)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementSelectionStateToBe(element, true));


                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(element);
                        break;

                    default: break;
                }
            }
            catch (Exception)
            {
                AssertionManager.Fail("Following element selection state is not TRUE : " + element + " at URL : " + HooksManager.driver.Url);
            }
        }
        public void UntilIsElementSelectionStateToBeFalse(IWebElement element)
        {
            ForDocumentToBeReady();
            try
            {
                WebDriverWait wait = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, webDriverExplictTimeoutInSeconds));
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementSelectionStateToBe(element, false));
                switch (browser)
                {
                    case "Chrome":
                        ScrollToWebElement(element);
                        break;

                    default: break;
                }
            }
            catch (Exception)
            {
                AssertionManager.Fail("Following element selection state is not FALSE : " + element + " at URL : " + HooksManager.driver.Url);
            }
        }

        private void ScrollToWebElement(IWebElement element)
        {
            try
            {
                ((IJavaScriptExecutor)HooksManager.driver).ExecuteScript("arguments[0].scrollIntoView({behavior: 'instant', block: 'center', inline: 'nearest'});", element);
            }
            catch (Exception)
            {
            }
        }

        public void UntilElementValueIsDisplayed(IWebElement element)
        {
            bool textPresent = false;
            DateTime exptime = DateTime.Parse(DateTime.Now.ToString("H:mm:ss")).AddSeconds(60);
            DateTime CurrentTime = new DateTime();
            do
            {
                CurrentTime = DateTime.Parse(DateTime.Now.ToString("H:mm:ss"));
                if (element.GetAttribute("value").Length != 0)
                {
                    textPresent = true;
                }
                else if (CurrentTime > exptime && textPresent == false)
                {
                    throw new Exception("Element text not present");
                }
            }
            while (textPresent == false);
        }

        public void UntilElementTextIsDisplayed(IWebElement element)
        {
            bool textPresent = false;
            DateTime exptime = DateTime.Parse(DateTime.Now.ToString("H:mm:ss")).AddSeconds(60);
            DateTime CurrentTime = new DateTime();
            do
            {
                CurrentTime = DateTime.Parse(DateTime.Now.ToString("H:mm:ss"));
                if (element.Text.Length != 0)
                {
                    textPresent = true;
                }
                else if (CurrentTime > exptime && textPresent == false)
                {
                    throw new Exception("Element text not present");
                }
            }
            while (textPresent == false);
        }

        public void UntilElementIsEnabled(IWebElement element)
        {
            bool elementEnabled = false;
            DateTime exptime = DateTime.Parse(DateTime.Now.ToString("H:mm:ss")).AddSeconds(30);
            DateTime CurrentTime = new DateTime();
            do
            {
                CurrentTime = DateTime.Parse(DateTime.Now.ToString("H:mm:ss"));
                if (element.Enabled)
                {
                    elementEnabled = true;
                }
                else if (CurrentTime > exptime && elementEnabled == false)
                {
                    throw new Exception("Timeout: Element is not enabled");
                }
            }
            while (elementEnabled == false);
        }

        #endregion
    }
}
