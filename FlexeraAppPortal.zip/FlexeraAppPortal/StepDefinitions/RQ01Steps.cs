﻿using FlexeraAppPortal.Framework;
using FlexeraAppPortal.PageObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexeraAppPortal.StepDefinitions
{
    [Binding]
    public class RQ01Steps
    {
        AppPortalPages appportalpage = new AppPortalPages();
        WaitManager wait= new WaitManager();
        ActionManager action = new ActionManager();

        [Given(@"admin user is logged into the app portal")]
        public void GivenAdminUserIsLoggedIntoTheAppPortal()
        {
            //wait.UntilIsElementIsDisplayed(By.XPath("//span[contains(text(),'Welcome')]"));
            AssertionManager.Displayed(appportalpage.Text_AppPortalWelcome);
        }

        [When(@"user navigate to the Catalog Behavior Page\(Admin >> Site Management >> Settings >> Web Site >> Catalog Behavior Page\)")]
        public void WhenUserNavigateToTheCatalogBehaviorPageAdminSiteManagementSettingsWebSiteCatalogBehaviorPage()
        {
            action.Click(appportalpage.Tab_Admin);
            action.Click(appportalpage.Tab_SiteManagement);
            action.Click(appportalpage.Tab_Settings);
            action.Click(appportalpage.Tab_WebSite);            
            action.SwitchToFrame(appportalpage.Tab_Frame);
            action.Click(appportalpage.Tab_CatalogBehaviour);
        }

        [Then(@"the page should display Enable advance search options checkbox")]
        public void ThenThePageShouldDisplayEnableAdvanceSearchOptionsCheckbox()
        {
            AssertionManager.Displayed(appportalpage.CheckBox_EnableAdvanceSearchOptions);
        }

        [Then(@"Enable advance search options check box should be checked\(by default\)")]
        public void ThenEnableAdvanceSearchOptionsCheckBoxShouldBeCheckedByDefault()
        {
            AssertionManager.Checked(appportalpage.CheckBox_EnableAdvanceSearchOptions);
        }

        [When(@"user uncheck the Enable advance search options checkbox")]
        public void WhenUserUncheckTheEnableAdvanceSearchOptionsCheckbox()
        {
            action.Click(appportalpage.CheckBox_EnableAdvanceSearchOptions);
        }

        [Then(@"Enable advance search options checkbox should be displayed as unchecked")]
        public void ThenEnableAdvanceSearchOptionsCheckboxShouldBeDisplayedAsUnchecked()
        {
            AssertionManager.UnChecked(appportalpage.CheckBox_EnableAdvanceSearchOptions);
        }

    }
}
