﻿using AppPortalFlexera.Framework;
using AppPortalFlexera.Pages;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppPortalFlexera.CommonClass;
using NUnit.Framework;
using AventStack.ExtentReports.Utils;
using AventStack.ExtentReports.Gherkin.Model;
using WindowsInput.Native;
using Microsoft.AspNetCore.Http;

namespace AppPortalFlexera.StepDefinitions
{
    [Binding]
    public class RQ06_AbilityToShowTheSearchHistoryBasedOnTheUserProfileSteps
    {
        AppPortalPages appPortalPages = new AppPortalPages();
        ActionManager action = new ActionManager();
        WaitManager wait = new WaitManager();
        IWebDriver driverRQ06 = null;
        IList<IWebElement> lstWebElement = new List<IWebElement>();
        List<string> lstString = new List<string>();
        List<string> sqlSuggestionList = new List<string>();
        string query;
        static ClassCommon classcommon = new ClassCommon();
        string userName = classcommon.getDataFromFile("username");

        [When(@"user clicks on the search box from the app portal application")]
        public void WhenUserClicksOnTheSearchBoxFromTheAppPortalApplication()
        {
            action.Click(appPortalPages.TextBox_InputMainSearchCatalog);
        }

        [Then(@"system should display the list of search keyword suggestions based on the past history\(as the logged in user past search keywords\)")]
        public void ThenSystemShouldDisplayTheListOfSearchKeywordSuggestionsBasedOnThePastHistoryAsTheLoggedInUserPastSearchKeywords()
        {
            query = "SELECT Top 10 SearchKeyword, MAX(searchdate) AS searchdate FROM [WD_UserSearchHistory] WHERE SearchDate > DATEADD(DAY, -90, GETDATE())  and UserName='" + userName + "' GROUP BY SearchKeyword ORDER BY searchdate DESC";
            

            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSuggestionList.Add(searchKeywordValue);
            }
            sqlSuggestionList = sqlSuggestionList.OrderBy(x => x.ToString()).ToList();
            reader.Close();

            List<string> suggestionList = new List<string>();

            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionValues = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if(suggestionValues.Count <= 10)
            {
                foreach(var value in suggestionValues)
                {
                    suggestionList.Add(value.Text.ToString().Trim());
                }
            }
            else 
            {              
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            Assert.AreEqual(sqlSuggestionList, suggestionList);           

        }

        [Then(@"system should display the list of unique historical search keyword suggestions")]
        public void ThenSystemShouldDisplayTheListOfUniqueHistoricalSearchKeywordSuggestions()
        {
            List<string> suggestionList = new List<string>();

            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionValues = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionValues.Count == 10)
            {
                foreach (var value in suggestionValues)
                {
                    suggestionList.Add(value.Text.ToString().Trim());
                }

                for (int i = 0; i < suggestionList.Count; i++)
                {
                    for (int j = i + 1; j < suggestionList.Count; j++)
                    {
                        string iStr = suggestionList[i];
                        string jStr = suggestionList[j];
                        if (suggestionList[i].ToLower() == suggestionList[j].ToLower())
                        {
                            throw new Exception(string.Format("In Auto Search Suggestions List Duplicate Items Found"));
                        }
                    }
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }
        }

        [Then(@"the list of unique historical search keyword suggestions should not contain the search keyword which is not searched earlier by him")]
        public void ThenTheListOfUniqueHistoricalSearchKeywordSuggestionsShouldNotContainTheSearchKeywordWhichIsNotSearchedEarlierByHim()
        {
            string query = "Select distinct SearchKeyword FROM WD_UserSearchHistory Where UserName ='" + userName + "'";
            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSuggestionList.Add(searchKeywordValue);
            }
            sqlSuggestionList = sqlSuggestionList.OrderBy(x => x.ToString()).ToList();
            reader.Close();

            List<string> suggestionList = new List<string>();

            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionValues = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionValues.Count == 10)
            {
                foreach (var value in suggestionValues)
                {
                    suggestionList.Add(value.Text.ToString().Trim());
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            for (int i = 0; i < suggestionList.Count; i++)
            {
                Assert.Contains(suggestionList[i], sqlSuggestionList);               
            }
            
        }

        [Then(@"system should not display the list of unique historical search keyword suggestions as loggin user has not used the search field to search the catalog item")]
        public void ThenSystemShouldNotDisplayTheListOfUniqueHistoricalSearchKeywordSuggestionsAsLogginUserHasNotUsedTheSearchFieldToSearchTheCatalogItem()
        {
            IList<IWebElement> suggestionValues = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionValues.Count == 0)
            {
                Console.WriteLine("No search history found for logged user");
            }
            else
            {
                throw new Exception(string.Format("History of logged user displayed"));
            }
        }

        [Then(@"user should not be able to see the search keyword of different user")]
        public void ThenUserShouldNotBeAbleToSeeTheSearchKeywordOfDifferentUser()
        {
            string query = "Select distinct SearchKeyword FROM WD_UserSearchHistory Where UserName !='" + userName + "'";
            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);

            while (reader.Read())
            {
                string searchKeywordValue = reader["SearchKeyword"].ToString();
                sqlSuggestionList.Add(searchKeywordValue);
            }
            sqlSuggestionList = sqlSuggestionList.OrderBy(x => x.ToString()).ToList();
            reader.Close();

            List<string> suggestionList = new List<string>();

            Thread.Sleep(6000);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionValues = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionValues.Count == 10)
            {
                foreach (var value in suggestionValues)
                {
                    suggestionList.Add(value.Text.ToString().Trim());
                }
            }
            else
            {
                throw new Exception(string.Format("Auto Search Suggestions are not displayed"));
            }

            for (int i = 0; i < suggestionList.Count; i++)
            {
                if (suggestionList[i].Contains(sqlSuggestionList.ToString()))
                {
                    throw new Exception(string.Format("Auto Search Suggestions displaying other users data"));
                }
            }
            
        }

        [When(@"user navigate to the User Impersonation page\(Admin >> Site Management >> Active Directory >> User Impersonation\)")]
        public void WhenUserNavigateToTheUserImpersonationPageAdminSiteManagementActiveDirectoryUserImpersonation()
        {
            HooksManager.driver.SwitchTo().DefaultContent();

            action.Click(appPortalPages.Tab_Admin);
            if (!HooksManager.driver.FindElement(By.XPath("//a[@id='tnActiveDirectory']//span[text()='Active Directory']")).Displayed)
            {
                wait.UntilIsElementIsClickable(appPortalPages.Tab_SiteManagement);
                action.Click(appPortalPages.Tab_SiteManagement);
            }
            else
            {
                action.Click(appPortalPages.Expandable_ActiveDirectory);
            }
            action.Click(appPortalPages.Expandable_UserImpersonation);
        }
        [When(@"click on new button")]
        public void WhenClickOnNewButton()
        {
            HooksManager.driver.SwitchTo().Frame("ctl00_cph1_topPane");
            action.Click(appPortalPages.Btn_ImpersonationNew);
        }

        [When(@"user select the account to impersonate")]
        public void WhenUserSelectTheAccountToImpersonate()
        {
            HooksManager.driver.SwitchTo().DefaultContent();
            HooksManager.driver.SwitchTo().Frame(appPortalPages.Window_NewImpersonation);
            action.SendKeys(appPortalPages.TextBox_AccountToImpersonate, classcommon.getDataFromFile("impersonateUser"));
        }
        [When(@"user select from drop down accounts with permissions to impersonate")]
        public void WhenUserSelectFromDropDownAccountsWithPermissionsToImpersonate()
        {
            string strValue;
            action.Click(appPortalPages.DropDownArrow_SelectAccountToImpersonateClick);
            Thread.Sleep(1000);
            IList<IWebElement> listWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='rcbScroll rcbWidth']//li"));
            Thread.Sleep(1000);
            foreach (IWebElement element in listWebElement)
            {
                strValue = element.Text;
                if (strValue == "appportal.flexdev.com")
                {
                    element.Click();
                    Thread.Sleep(1000);
                }
            }
        }

        [When(@"select the current user, click on add selected account")]
        public void WhenSelectTheCurrentUserClickOnAddSelectedAccount()
        {
            action.SendKeys(appPortalPages.TextBox_CurrentUserImpersonate, classcommon.getDataFromFile("currentUserInImpersonate"));
            action.Click(appPortalPages.Btn_SearchImpersonation);
        }

        [Then(@"the selected user should display in the current account text area")]
        public void ThenTheSelectedUserShouldDisplayInTheCurrentAccountTextArea()
        {
            if (HooksManager.driver.FindElement(By.XPath("//li[@id='ctl00_cph1_SecurityGroupPicker1_lbSearchResults_i0']/span[@class='rlbText']")).Displayed)
            {
                action.Click(appPortalPages.TextArea_SearchResultArea);
                Console.WriteLine("Selected Current user Displaying");
                action.Click(appPortalPages.Btn_AddSelectedAccount);

                if (HooksManager.driver.FindElement(By.Id("ctl00_cph1_rlbImpersonate_i0")).Displayed)
                {
                    action.Click(appPortalPages.TextArea_ImpersonatedAccountArea);
                    Console.WriteLine("Selected Current Account Displaying");
                }
                else
                {
                    throw new Exception(string.Format("Selected Current Account Not Displaying"));
                }
            }
            else
            {
                throw new Exception(string.Format("Selected Current User Not Displaying"));
            }
        }

        [Then(@"click on save button on New Impersonation popup page")]
        public void ThenClickOnSaveButtonOnNewImpersonationPopupPage()
        {
            action.Click(appPortalPages.Btn_ImpersonationSave);
        }

        [When(@"user close the New Impersonation popup page")]
        public void WhenUserCloseTheNewImpersonationPopupPage()
        {
            HooksManager.driver.SwitchTo().DefaultContent();
            action.Click(appPortalPages.Btn_crossCloseButton);
        }

        [Then(@"system should not display the New Impersonation popup page")]
        public void ThenSystemShouldNotDisplayTheNewImpersonationPopupPage()
        {
            lstWebElement = HooksManager.driver.FindElements(By.XPath("//em[text()='New Impersonation']"));
            if (lstWebElement.Count != 0)
            {
                throw new Exception(string.Format("New Impersonation Page not closed"));
            }
        }

        [When(@"user select the account details of impersonated user")]
        public void WhenUserSelectTheAccountDetailsOfImpersonatedUser()
        {
            Thread.Sleep(2000);
            HooksManager.inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB).KeyDown(VirtualKeyCode.DOWN);

            Thread.Sleep(3000);
            HooksManager.inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);

            Thread.Sleep(3000);
            HooksManager.inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(10000);
        }

        [When(@"user selected from the list of displayed search keyword suggestions")]
        public void WhenUserSelectedFromTheListOfDisplayedSearchKeywordSuggestions()
        {
            Thread.Sleep(2000);
            String strText = "";
            action.Click(appPortalPages.TextBox_InputMainSearchCatalog);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            IList<IWebElement> suggestionList = HooksManager.driver.FindElements(By.XPath("//ul[@role='listbox']/child::li"));
            if (suggestionList.Count > 0)
            {
                Random rnd = new Random();
                int randomNumber = rnd.Next(0, suggestionList.Count-1);

                for (int i = 0; i < suggestionList.Count; i++)
                {
                    if (randomNumber == i)
                    {
                        suggestionList[i].Click();
                        strText = suggestionList[i].Text;
                        Thread.Sleep(1500);
                        Console.WriteLine("Clicked on suggestion list: " + strText);
                        action.Click(appPortalPages._btnSearchButton);
                        break;
                    }
                }
            }
        }

        [Then(@"system should display the search result for the selected search suggestion option data")]
        public void ThenSystemShouldDisplayTheSearchResultForTheSelectedSearchSuggestionOptionData()
        {
            WebDriverWait wait1;
            string searchtermresult = ""; string resultCountMessage = "";
            bool flag = false;
            wait1 = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, 90));
            wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//img[@id='ajax-load-indicator']")));

            searchtermresult = HooksManager.driver.FindElement(By.Id("resultsCategoryHeader")).Text.Replace('"', ' ').Trim();

            // IList<IWebElement> lstWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='cataloglistonscroll']//div[@class='showcaseCardBody']/div"));
            IList<IWebElement> lstWebElement = HooksManager.driver.FindElements(By.XPath("//div[contains(@class,'cataloglistonscroll')]//div[@class='showcaseCardBody']/div[@class='showcaseCardTitle']"));

            foreach (IWebElement element in lstWebElement)
            {
                if (element.Text != "")
                {
                    lstString.Add(element.Text.Trim());
                }
            }

            if (lstString.Count > 0)
            {
                flag = lstString.Contains(appPortalPages.TextBox_InputMainSearchCatalog.Text);
            }
            else
            {
                wait1 = new WebDriverWait(HooksManager.driver, new TimeSpan(0, 0, 90));
                wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//img[@id='ajax-load-indicator']")));

                searchtermresult = HooksManager.driver.FindElement(By.Id("resultsCategoryHeader")).Text.Replace('"', ' ').Trim();
                resultCountMessage = HooksManager.driver.FindElement(By.XPath("//div[@id='resultsCountHeader']/div[text()='There was no result for your search.']")).Text.Trim();

                // wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
                // wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));
                Assert.AreEqual(RQ05_StepDefinitions.selectedTitle, searchtermresult, "The search term result displayed is incorrect");
                Assert.AreEqual("There was no result for your search.", resultCountMessage, "The result count message displayed is incorrect");
            }

            if (flag)
            {
                Assert.False(flag);
            }
            else
            {
                Console.WriteLine("Searched data not matching and testcase pass");
            }
        }
    }
}
