﻿using FlexeraAppPortal.Framework;
using FlexeraAppPortal.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexeraAppPortal.StepDefinitions
{
    public class RQ02Steps
    {
        AppPortalPages appportalpage = new AppPortalPages();
        WaitManager wait = new WaitManager();
        ActionManager action = new ActionManager();

        [Then(@"the Admin should be able to view the different search terms \(Title, Brief Description, Full Description, Keyword\)")]
        public void ThenTheAdminShouldBeAbleToViewTheDifferentSearchTermsTitleBriefDescriptionFullDescriptionKeyword()
        {
            throw new PendingStepException();
        }

        [Then(@"the Admin should be able to view the different Enable advance search options\(Enable search by catalog classification,Enable search result display based on catalog classification,Enable fuzzy logic search,Enable search history based on user profile\) check boxes")]
        public void ThenTheAdminShouldBeAbleToViewTheDifferentEnableAdvanceSearchOptionsEnableSearchByCatalogClassificationEnableSearchResultDisplayBasedOnCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxes()
        {
            throw new PendingStepException();
        }

        [Then(@"Admin user should be able to view the Title search term with the check box")]
        public void ThenAdminUserShouldBeAbleToViewTheTitleSearchTermWithTheCheckBox()
        {
            throw new PendingStepException();
        }

        [Then(@"Title search term check box should be enabled and checked\(by default\)")]
        public void ThenTitleSearchTermCheckBoxShouldBeEnabledAndCheckedByDefault()
        {
            throw new PendingStepException();
        }

        [When(@"Admin user click\(uncheck\) on the Title search term check box")]
        public void WhenAdminUserClickUncheckOnTheTitleSearchTermCheckBox()
        {
            throw new PendingStepException();
        }

        [Then(@"The Title search term check box should display as unchecked")]
        public void ThenTheTitleSearchTermCheckBoxShouldDisplayAsUnchecked()
        {
            throw new PendingStepException();
        }

        [When(@"Admin user click\(check\) on the Title search term check box")]
        public void WhenAdminUserClickCheckOnTheTitleSearchTermCheckBox()
        {
            throw new PendingStepException();
        }

        [Then(@"The Title search term check box should display as checked")]
        public void ThenTheTitleSearchTermCheckBoxShouldDisplayAsChecked()
        {
            throw new PendingStepException();
        }

        [Then(@"Admin user should be able to view the Full description,Brief description and Keyword search terms with the check box as enable")]
        public void ThenAdminUserShouldBeAbleToViewTheFullDescriptionBriefDescriptionAndKeywordSearchTermsWithTheCheckBoxAsEnable()
        {
            throw new PendingStepException();
        }

        [Then(@"Full description,Brief description and Keyword search terms check boxs should be displayed as unchecked")]
        public void ThenFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsShouldBeDisplayedAsUnchecked()
        {
            throw new PendingStepException();
        }

        [When(@"Admin user click\(check\) on the Full description,Brief description and Keyword search terms check boxs")]
        public void WhenAdminUserClickCheckOnTheFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxs()
        {
            throw new PendingStepException();
        }

        [Then(@"Full description,Brief description and Keyword search terms check boxs should be displayed as checked")]
        public void ThenFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsShouldBeDisplayedAsChecked()
        {
            throw new PendingStepException();
        }

        [When(@"Admin user click\(uncheck\) on the Full description and Brief description search terms check boxs")]
        public void WhenAdminUserClickUncheckOnTheFullDescriptionAndBriefDescriptionSearchTermsCheckBoxs()
        {
            throw new PendingStepException();
        }

        [Then(@"Title,Full description,Brief description and Keyword search terms check boxs should be enable for the admin user")]
        public void ThenTitleFullDescriptionBriefDescriptionAndKeywordSearchTermsCheckBoxsShouldBeEnableForTheAdminUser()
        {
            throw new PendingStepException();
        }

        [Then(@"Enable search by catalog classification,Enable fuzzy logic search,Enable search history based on user profile check boxs should be enable for the admin user")]
        public void ThenEnableSearchByCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxsShouldBeEnableForTheAdminUser()
        {
            throw new PendingStepException();
        }

        [Then(@"all the Enabe advance search options terms should be unchecked\(by default\)")]
        public void ThenAllTheEnabeAdvanceSearchOptionsTermsShouldBeUncheckedByDefault()
        {
            throw new PendingStepException();
        }

        [Then(@"Enable search by catalog classification,Enable fuzzy logic search,Enable search history based on user profile check boxs should be disabled and unchecked for the admin user")]
        public void ThenEnableSearchByCatalogClassificationEnableFuzzyLogicSearchEnableSearchHistoryBasedOnUserProfileCheckBoxsShouldBeDisabledAndUncheckedForTheAdminUser()
        {
            throw new PendingStepException();
        }

        [Then(@"“Enable advance search options” check box should be checked\(by default\)")]
        public void ThenEnableAdvanceSearchOptionsCheckBoxShouldBeCheckedByDefault()
        {
            throw new PendingStepException();
        }

        [When(@"user click on\(check\) the Enable search by catalog classification check box")]
        public void WhenUserClickOnCheckTheEnableSearchByCatalogClassificationCheckBox()
        {
            throw new PendingStepException();
        }

        [Then(@"Enable search result display based on catalog classification check box should be enable for the admin user")]
        public void ThenEnableSearchResultDisplayBasedOnCatalogClassificationCheckBoxShouldBeEnableForTheAdminUser()
        {
            throw new PendingStepException();
        }

        [When(@"user clicks on\(check\) the Enable search result display based on catalog classification check box")]
        public void WhenUserClicksOnCheckTheEnableSearchResultDisplayBasedOnCatalogClassificationCheckBox()
        {
            throw new PendingStepException();
        }

        [Then(@"system should dispaly the Enable search result display based on catalog classification check box as checked")]
        public void ThenSystemShouldDispalyTheEnableSearchResultDisplayBasedOnCatalogClassificationCheckBoxAsChecked()
        {
            throw new PendingStepException();
        }

        [When(@"user click on\(uncheck\) the Enable search by catalog classification check box")]
        public void WhenUserClickOnUncheckTheEnableSearchByCatalogClassificationCheckBox()
        {
            throw new PendingStepException();
        }

        [Then(@"Enable search result display based on catalog classification check box should be disable for the admin user")]
        public void ThenEnableSearchResultDisplayBasedOnCatalogClassificationCheckBoxShouldBeDisableForTheAdminUser()
        {
            throw new PendingStepException();
        }

    }
}
