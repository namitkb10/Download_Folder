﻿using OpenQA.Selenium;
using AppPortalFlexera.Pages;
using AppPortalFlexera.Framework;
using OpenQA.Selenium.Interactions;
using NUnit.Framework;
using LivingDoc.Dtos;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Http;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using static ICSharpCode.SharpZipLib.Zip.ExtendedUnixData;

namespace AppPortalFlexera.StepDefinitions
{
    [Binding]
    public class RQ05_StepDefinitions
    {
        AppPortalPages appPortalPages = new AppPortalPages();
        WaitManager wait = new WaitManager();
        ActionManager action = new ActionManager();
        public static string selectedTitle = string.Empty;
        List<string> lstString = new List<string>();
        bool flag = false;

        [Then(@"system should display the search results based on Preferred,Non-Classified,Non-preferred catalog items order")]
        public void ThenSystemShouldDisplayTheSearchResultsBasedOnPreferredNon_ClassifiedNon_PreferredCatalogItemsOrder()
        {
            IList<IWebElement> listWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='showcaseCardOuter']"));

            List<string> itemsList = new List<string>();
            List<string> itemsList1 = new List<string>();
            foreach (WebElement value in listWebElement)
            {
                string value1 = value.GetAttribute("data-classificationsort");
                itemsList.Add(value1);
                itemsList1.Add(value1);
            }
            var flag = true;
            itemsList1.Sort();

            for (int i = 0; i < itemsList.Count; i++)
            {
                if (itemsList[i] != itemsList1[i])
                {
                    flag = false;
                    break;
                }
            }

            if (flag == false)
            {
                throw new Exception(string.Format("Displayed Catalog Classification is not in expected order"));
            }

        }

        [Then(@"all the Preferred,Non-classified,Non-preferred catalog items should be sorted alphabetically in respective classifications")]
        public void ThenAllThePreferredNon_ClassifiedNon_PreferredCatalogItemsShouldBeSortedAlphabeticallyInRespectiveClassifications()
        {
            var alphabetical = true;
            List<string> actualLinkList = new List<string>(); ;
            List<string> newSortedList = new List<string>(); ;

            for (int i = 0; i <= 2; i++)
            {
                IList<IWebElement> listWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='cataloglistonscroll" + i + "']//div[@class='showcaseCardTitle']"));
                
                foreach (var item in listWebElement)
                {
                    actualLinkList.Add(item.Text);
                    newSortedList.Add(item.Text);
                }

                newSortedList.Sort();

                if (actualLinkList.Count > 1)
                {
                    alphabetical = true;
                    for (int j = 0; j < actualLinkList.Count - 1; j++)
                    {
                        if (actualLinkList[j] != newSortedList[j])
                        {
                            alphabetical = false;
                            break;
                        }
                    }
                }
                if (alphabetical == false)
                {
                    throw new Exception(string.Format("Displayed data is not in sorted order"));
                }
            }
        }

        [When(@"user navigate to the General popup Page\(Admin >> Catalog Management >> Current Catalog Items >>View All Item >> Double Click on any items >> A new window\(pop-up\) will open\)")]
        public void WhenUserNavigateToTheGeneralPopupPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItemsANewWindowPop_UpWillOpen()
        {
            HooksManager.driver.SwitchTo().DefaultContent();

            action.Click(appPortalPages.Tab_Admin);
            IWebElement element = HooksManager.driver.FindElement(By.Id("tnRequestManagement"));
            string value = element.GetAttribute("class");
            if (!value.Contains("rpExpanded"))
            {
                wait.UntilIsElementIsClickable(appPortalPages.Tab_CatalogManagement);
                action.Click(appPortalPages.Tab_CatalogManagement);
                IWebElement element1 = HooksManager.driver.FindElement(By.Id("nodeCurrentRequests"));
                string value1 = element1.GetAttribute("class");
                if (!value1.Contains("rpExpanded"))
                {
                    action.Click(appPortalPages.Tab_CurrentCatalogItems);
                    AssertionManager.Displayed(appPortalPages.Tab_ViewAllItems);
                    action.Click(appPortalPages.Tab_ViewAllItems);
                }

            }
            AssertionManager.Displayed(appPortalPages.Tab_ViewAllItems);
            action.Click(appPortalPages.Tab_ViewAllItems);

            action.SwitchToFrame(appPortalPages.Tab_Frame);
            List<List<string>> ItemDetails = ActionManager.GetAllGridDataIntoList(appPortalPages.TableRows_ItemDetails, appPortalPages.TableColumns_ItemDetails);

            if (ItemDetails.Count > 0)
            {
                IWebElement element1 = HooksManager.driver.FindElement(By.XPath("//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr[2]/td[2]"));
                selectedTitle = element1.Text.ToString().Trim();
                Actions act = new Actions(HooksManager.driver);
                act.DoubleClick(element1).Perform();
            }
            
            else
            {
                throw new Exception(string.Format("Item list is not dispalyed"));
            }
            HooksManager.driver.SwitchTo().DefaultContent();
            action.SwitchToFrame(appPortalPages.Tab_GeneralFrame);
                   
        }

        [When(@"user uncheck the Is enabled check box\(In Global\(Tab\) >> Inside Global Options box>>is enabled check box\)")]
        public void WhenUserUncheckTheIsEnabledCheckBoxInGlobalTabInsideGlobalOptionsBoxIsEnabledCheckBox()
        {
            if (appPortalPages.CheckBox_IsEnabled.Selected)
            {
                action.Click(appPortalPages.CheckBox_IsEnabled);
            }
        }

        [When(@"user check the Is enabled check box\(In Global\(Tab\) >> Inside Global Options box>>is enabled check box\)")]
        public void WhenUserCheckTheIsEnabledCheckBoxInGlobalTabInsideGlobalOptionsBoxIsEnabledCheckBox()
        {
            if (!appPortalPages.CheckBox_IsEnabled.Selected)
            {
                action.Click(appPortalPages.CheckBox_IsEnabled);
            }
        }

        [When(@"user check at least one category is selected")]
        public void WhenUserCheckAtLeastOneCategoryIsSelected()
        {
            throw new PendingStepException();
        }


        [When(@"click on Save button and verify the message")]
        public void WhenClickOnSaveButtonAndVerifyTheMessage()
        {

            action.Click(appPortalPages.Btn_GlobalSave);
            AssertionManager.Equals(appPortalPages.Text_CatalogSaveMessage.Text, "Successfully updated catalog item.");
        }

        [When(@"click on save button and system display the message on the general popup")]
        public void WhenClickOnSaveButtonAndSystemDisplayTheMessageOnTheGeneralPopup()
        {
            IList<IWebElement> elements = HooksManager.driver.FindElements(By.XPath("//input[@id='ctl00_cph1_cboCategory_ClientState' and contains(@value,'categories selected')]"));
            /*IWebElement Category = HooksManager.driver.FindElement(By.XPath("//span[@id='ctl00_cph1_rfvCat']"));
            string value = Category.GetAttribute("style");
            if (!value.Contains("visible"))*/
            if(elements.Count == 0)
            {
                action.Click(appPortalPages.DropDown_Category);
                IWebElement categoryOption = HooksManager.driver.FindElement(By.XPath("//div[@class='rtTop']//label//input[@type='checkbox']"));
                Thread.Sleep(1000);
                action.Click(categoryOption);
                IWebElement element1 = HooksManager.driver.FindElement(By.XPath("//input[@id='ctl00_cph1_cboCategory_ClientState']"));
                string categoryvalue = element1.GetAttribute("value");
                Assert.IsTrue(categoryvalue.Contains("selected"), "category value is not checked/selected");
            }
            action.Click(appPortalPages.Button_Save);
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            wait.UntilElementTextIsDisplayed(appPortalPages.Text_PopupSaveMessage);

            if (!appPortalPages.Text_PopupSaveMessage.Displayed)
            {
                throw new Exception(string.Format("Saved message is not displayed"));
            }
        }

        [Then(@"Is enabled check box should display as unchecked")]
        public void ThenIsEnabledCheckBoxShouldDisplayAsUnchecked()
        {
            AssertionManager.UnChecked(appPortalPages.CheckBox_IsEnabled);
        }

        [When(@"user close the general settings popup page")]
        public void WhenUserCloseTheGeneralSettingsPopupPage()
        {
            HooksManager.driver.SwitchTo().DefaultContent();
            action.Click(appPortalPages.Button_Close);
        }

        [Then(@"system should not display the general settings popup page")]
        public void ThenSystemShouldNotDisplayTheGeneralSettingsPopupPage()
        {
            IList<IWebElement> closeButton = HooksManager.driver.FindElements(By.XPath("//a[@class='rwCloseButton']"));
            if (closeButton.Count != 0)
            {
                throw new Exception(string.Format("General Settings pop - up is not closed"));
            }
        }

        [When(@"user navigate to the browser catalog tab")]
        public void WhenUserNavigateToTheBrowserCatalogTab()
        {
            HooksManager.driver.SwitchTo().DefaultContent();
            action.Click(appPortalPages.Tab_BrowseCatalog);
        }

        [When(@"user search by the title search term related data from the search text box")]
        public void WhenUserSearchByTitleSearchTermRelatedDataFromTheSearchTextBox()
        {
            // HooksManager.driver.SwitchTo().DefaultContent();
            action.SendKeys(appPortalPages.TextBox_InputMainSearchCatalog, selectedTitle);
            action.Click(appPortalPages.Button_Search);       
        }

        [Then(@"system should not display the search results for the given title search term data")]
        public void ThenSystemShouldNotDisplayTheSearchResultsForTheGivenTitleSearchTermData()
        {
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            string searchtermresult = appPortalPages.Text_SearchResult.Text.Replace('"', ' ').Trim();
            wait.UntilIsElementIsDisplayed(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]"));
            Assert.AreEqual(selectedTitle, searchtermresult, "The search term result displayed is incorrect");

            // IList<IWebElement> lstWebElement = driverRQ04.FindElements(By.XPath("//div[@class='cataloglistonscroll1']//div[@class='showcaseCardBody']/div"));
            verifyTheSearchResult();
        }

        public void verifyTheSearchResult()
        {
            IList<IWebElement> lstWebElement = HooksManager.driver.FindElements(By.XPath("//div[@class='showcaseCardBody']/div[@class='showcaseCardTitle']"));

            foreach (IWebElement element in lstWebElement)
            {
                if (element.Text != "")
                {
                    lstString.Add(element.Text);
                }
            }

            if (lstString.Count > 0)
            {
                flag = lstString.Contains(selectedTitle);
            }
            else
            {
                AssertionManager.ElementTextEquals(appPortalPages.Text_NoSearchResult, "There was no result for your search.");
                //wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
                //wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//img[@id='ajax-load-indicator']")));

                //searchtermresult = driverRQ04.FindElement(By.Id("resultsCategoryHeader")).Text.Replace('"', ' ').Trim();
                //resultCountMessage = driverRQ04.FindElement(By.XPath("//div[@id='resultsCountHeader']/div[text()='There was no result for your search.']")).Text.Trim();

                //// wait1 = new WebDriverWait(driverRQ04, new TimeSpan(0, 0, 90));
                //// wait1.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//div//h1[contains(text(),'" + searchtermresult + "')]")));
                //Assert.AreEqual(RQ05_StepDefinitions.selectedTitle, searchtermresult, "The search term result displayed is incorrect");
                //Assert.AreEqual("There was no result for your search.", resultCountMessage, "The result count message displayed is incorrect");
            }

            if (flag)
            {
                Assert.False(flag);
            }
            else
            {
                Console.WriteLine("Searched data not matching with the list, pass");
            }
        }

        [When(@"click on Archive button and system display the message on the general popup")]
        public void WhenClickOnArchiveButtonAndSystemDisplayTheMessageOnTheGeneralPopup()
        {           
            action.Click(appPortalPages.Button_Archive);
            HooksManager.driver.SwitchTo().Alert().Accept();
            wait.UntilIsElementIsNotDisplayed(By.XPath("//img[@id='ajax-load-indicator']"));
            wait.UntilElementTextIsDisplayed(appPortalPages.Text_ArchiveMessage);

            if (!appPortalPages.Text_ArchiveMessage.Displayed)
            {
                throw new Exception(string.Format("Archived message is not displayed"));
            }
        }

        [Then(@"archived data should not display in the item search grid")]
        public void ThenArchivedDataShouldNotDisplayInTheItemSearchGrid()
        {
            List<string> titleValues = new List<string>();
            action.SwitchToFrame(appPortalPages.Tab_Frame);
            List<List<string>> ItemDetails = ActionManager.GetAllGridDataIntoList(appPortalPages.TableRows_ItemDetails, appPortalPages.TableColumns_ItemDetails);

            if (ItemDetails.Count > 0)
            {
                for(int i=0; i<ItemDetails.Count; i++)
                {
                    IWebElement element1 = HooksManager.driver.FindElement(By.XPath("//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr[" + (i + 1) + "]/td[2]"));
                    string titleText = element1.Text.ToString().Trim();
                    titleValues.Add(titleText);
                    if (titleValues[i] == selectedTitle)
                    {
                        throw new Exception(string.Format("Archived data is displaying in the item search grid"));
                    }
                }
                
            }

            else
            {
                throw new Exception(string.Format("Item list is not dispalyed"));
            }
            
        }

        [Then(@"user update the Archived data in the SQL")]
        public void ThenUserUpdateTheArchivedDataInTheSQL()
        {
            string query = "Update WD_WebPackages set PackageVisible=1, Deleted=0 Where PackageTitle='" + selectedTitle + "'";
            SqlDataReader reader = HooksManager.connectAppPortal.ExecuteReader(CommandType.Text, query);

            reader.Close();
        }


    }
}
