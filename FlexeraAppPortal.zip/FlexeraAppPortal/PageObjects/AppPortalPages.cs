﻿using FlexeraAppPortal.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexeraAppPortal.PageObjects
{
    public class AppPortalPages
    {
        public AppPortalPages()
        {

            PageFactory.InitElements(this, new RetryingElementLocator(DriverSetUpManager.driver, TimeSpan.FromSeconds(30)));
        }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Welcome')]")]
        public IWebElement Text_AppPortalWelcome { get; set; }

        //this id is checkbox id or the text id

        [FindsBy(How = How.Id, Using = "ctl00_cph1_AdvancSearch")]
        public IWebElement CheckBox_EnableAdvanceSearchOptions { get; set; }

        [FindsBy(How = How.Id, Using = "Admin")]
        public IWebElement Tab_Admin { get; set; }

        [FindsBy(How = How.Id, Using = "tnSiteConfiguration")]
        public IWebElement Tab_SiteManagement { get; set; }

        [FindsBy(How = How.Id, Using = "nodeSettings")]
        public IWebElement Tab_Settings { get; set; }

        [FindsBy(How = How.Id, Using = "RadPanelItem121")]
        public IWebElement Tab_WebSite{ get; set; }

        [FindsBy(How = How.Id, Using = "//span[contains(text(),'Catalog Behavior')]")]
        public IWebElement Tab_CatalogBehaviour { get; set; }

        [FindsBy(How = How.Id, Using = "RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane")]
        public IWebElement Tab_Frame { get; set; }

    }
}
