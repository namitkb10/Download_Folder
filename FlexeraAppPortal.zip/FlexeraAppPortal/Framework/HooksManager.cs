﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexeraAppPortal.Framework
{
    public class HooksManager
    {

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            DriverSetUpManager.DriverSetup();
            DriverSetUpManager.LoginSetUp();
        }

        [AfterScenario]
        public static void AfterScenario()
        {
            var CaptureManager = new CaptureManager(DriverSetUpManager.driver);
            CaptureManager.CaptureScreenshotAndPageSourceUponFailure();

        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            Console.WriteLine("After Scenario driver value is: " + DriverSetUpManager.driver);

            if (DriverSetUpManager.driver != null)
            {
                DriverSetUpManager.driver.Quit();
            }
        }
    }
}
